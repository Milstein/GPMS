TodoFX
======

A Todo Application built using JavaFX and MongoDB